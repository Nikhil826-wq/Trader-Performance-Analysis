﻿import argparse
import sys
from bot.client import create_client, get_current_price, get_symbol_info
from bot.orders import place_order
from bot.validators import (
    validate_order_type,
    validate_price,
    validate_quantity,
    validate_side,
    validate_symbol,
    validate_stop_price,
)
import bot.logging_config  # initializes logging


def parse_args():
    parser = argparse.ArgumentParser(description="Binance Futures Testnet CLI Bot")
    parser.add_argument("--symbol", required=True, type=str, help="Trading symbol e.g., BTCUSDT")
    parser.add_argument("--side", required=True, type=str, choices=["BUY", "SELL"], help="BUY or SELL")
    parser.add_argument(
        "--order-type",
        required=True,
        type=str,
        choices=["MARKET", "LIMIT", "STOP_LIMIT", "STOP_MARKET"],
        help="MARKET, LIMIT, STOP_LIMIT, or STOP_MARKET",
    )
    parser.add_argument("--quantity", required=True, type=float, help="Quantity to trade")
    parser.add_argument("--price", type=float, help="Price for LIMIT or STOP_LIMIT orders")
    parser.add_argument("--stop-price", type=float, help="Trigger price for STOP_LIMIT or STOP_MARKET orders")
    parser.add_argument("--env-file", default=".env", help="Path to dotenv file")
    return parser.parse_args()


def main():
    args = parse_args()

    try:
        client = create_client(env_file=args.env_file)
        symbol = args.symbol.upper()
        symbol_info = get_symbol_info(client, symbol)
        current_price = get_current_price(client, symbol)

        side = validate_side(args.side)
        order_type = validate_order_type(args.order_type)
        validate_symbol(symbol, symbol_info)
        quantity = validate_quantity(args.quantity, symbol_info)

        price = None
        stop_price = None
        if order_type == "LIMIT":
            price = validate_price(args.price, symbol_info)
        elif order_type == "STOP_LIMIT":
            price = validate_price(args.price, symbol_info)
            stop_price = validate_stop_price(args.stop_price, symbol_info, side, current_price)
        elif order_type == "STOP_MARKET":
            stop_price = validate_stop_price(args.stop_price, symbol_info, side, current_price)

        summary = f"Placing {order_type} order: {side} {quantity} {symbol}"
        if price:
            summary += f" at {price}"
        if stop_price:
            summary += f" stopPrice {stop_price}"
        print(summary)

        order = place_order(client, symbol, side, order_type, quantity, price, stop_price)
        print("Order Response:", order)

    except Exception as error:
        print("Error:", error)
        sys.exit(1)


if __name__ == "__main__":
    main()
