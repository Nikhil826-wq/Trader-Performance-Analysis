# Binance Futures Testnet CLI Bot

A simple CLI wrapper for Binance Futures Testnet order placement.

## Setup

1. Activate the virtual environment:
   ```powershell
   .\venv\Scripts\Activate.ps1
   ```
2. Create a `.env` file in the project root with:
   ```text
   BINANCE_API_KEY=your_api_key
   BINANCE_API_SECRET=your_api_secret
   ```
3. Confirm `.env` is ignored in `.gitignore`.

## Usage

### Market order

```powershell
python cli.py --symbol BTCUSDT --side BUY --order-type MARKET --quantity 0.01
```

### Limit order

```powershell
python cli.py --symbol BTCUSDT --side SELL --order-type LIMIT --quantity 0.01 --price 67000
```

### Stop-limit order

```powershell
python cli.py --symbol BTCUSDT --side SELL --order-type STOP_LIMIT --quantity 0.01 --price 67000 --stop-price 67100
```

### Stop-market order

```powershell
python cli.py --symbol BTCUSDT --side SELL --order-type STOP_MARKET --quantity 0.01 --stop-price 67100
```

### Custom env file path

```powershell
python cli.py --symbol BTCUSDT --side BUY --order-type MARKET --quantity 0.01 --env-file .env
```

## Validation

The CLI performs:

- symbol existence and trading status check using Binance exchange info
- LIMIT price validation against `PRICE_FILTER` tick size, minimum, and maximum
- quantity validation against `LOT_SIZE` minimum, maximum, and step size
- required price enforcement for `LIMIT` orders

## Logging

Order requests and responses are automatically saved to `trading_bot.log`.

Example log entries:

- `Order request: {...}`
- `Order response: {...}`

## Git

- `.env` is ignored by `.gitignore`
- `__pycache__/`, `venv/`, and `trading_bot.log` are also ignored

## Notes

- Always run `cli.py`, not `cli.py.py`
- Keep API credentials in `.env` only
- This project targets Binance Futures Testnet

## Future improvements

- Add stop-limit and OCO order support
- Add prompt-based interactive CLI mode
- Add order result formatting and better error messages
