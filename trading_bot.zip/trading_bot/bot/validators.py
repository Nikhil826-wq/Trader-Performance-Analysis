﻿from decimal import Decimal, InvalidOperation


def validate_side(side: str):
    side = side.upper()
    if side not in ["BUY", "SELL"]:
        raise ValueError("Side must be BUY or SELL")
    return side


def validate_order_type(order_type: str):
    order_type = order_type.upper()
    if order_type not in ["MARKET", "LIMIT", "STOP_LIMIT", "STOP_MARKET"]:
        raise ValueError("Order type must be MARKET, LIMIT, STOP_LIMIT, or STOP_MARKET")
    return order_type


def _decimal(value):
    try:
        return Decimal(str(value))
    except (InvalidOperation, TypeError):
        raise ValueError("Value must be numeric")


def _is_multiple(value, step):
    value = _decimal(value)
    step = _decimal(step)
    remainder = value % step
    return remainder == 0


def validate_positive_number(value: float, field_name: str):
    value = _decimal(value)
    if value <= 0:
        raise ValueError(f"{field_name} must be positive")
    return float(value)


def validate_symbol(symbol: str, symbol_info: dict):
    if not symbol:
        raise ValueError("Symbol is required")

    symbol = symbol.upper()
    if symbol_info.get("symbol") != symbol:
        raise ValueError(f"Symbol not supported: {symbol}")

    if symbol_info.get("status") != "TRADING":
        raise ValueError(f"Symbol is not trading: {symbol}")

    return symbol


def validate_price(price: float, symbol_info: dict):
    if price is None:
        raise ValueError("Price is required for LIMIT orders")

    price = _decimal(price)
    if price <= 0:
        raise ValueError("Price must be a positive number")

    price_filter = next(
        f for f in symbol_info.get("filters", []) if f.get("filterType") == "PRICE_FILTER"
    )
    tick_size = _decimal(price_filter["tickSize"])
    min_price = _decimal(price_filter["minPrice"])
    max_price = _decimal(price_filter["maxPrice"])

    if price < min_price:
        raise ValueError(f"Price must be at least {min_price}")
    if price > max_price:
        raise ValueError(f"Price must be at most {max_price}")
    if not _is_multiple(price, tick_size):
        raise ValueError(f"Price must be a multiple of tick size {tick_size}")

    return float(price)


def validate_stop_price(price: float, symbol_info: dict, side: str, current_price):
    if price is None:
        raise ValueError("Stop price is required for stop orders")

    price = _decimal(price)
    if price <= 0:
        raise ValueError("Stop price must be a positive number")

    price_filter = next(
        f for f in symbol_info.get("filters", []) if f.get("filterType") == "PRICE_FILTER"
    )
    tick_size = _decimal(price_filter["tickSize"])
    min_price = _decimal(price_filter["minPrice"])
    max_price = _decimal(price_filter["maxPrice"])

    if price < min_price:
        raise ValueError(f"Stop price must be at least {min_price}")
    if price > max_price:
        raise ValueError(f"Stop price must be at most {max_price}")
    if not _is_multiple(price, tick_size):
        raise ValueError(f"Stop price must be a multiple of tick size {tick_size}")

    if side == "BUY" and price <= current_price:
        raise ValueError(f"BUY stop orders require stop price above current market price ({current_price})")
    if side == "SELL" and price >= current_price:
        raise ValueError(f"SELL stop orders require stop price below current market price ({current_price})")

    return float(price)


def validate_quantity(quantity: float, symbol_info: dict):
    quantity = _decimal(quantity)
    if quantity <= 0:
        raise ValueError("Quantity must be a positive number")

    lot_filter = next(
        f for f in symbol_info.get("filters", []) if f.get("filterType") == "LOT_SIZE"
    )
    min_qty = _decimal(lot_filter["minQty"])
    max_qty = _decimal(lot_filter["maxQty"])
    step_size = _decimal(lot_filter["stepSize"])

    if quantity < min_qty:
        raise ValueError(f"Quantity must be at least {min_qty}")
    if quantity > max_qty:
        raise ValueError(f"Quantity must be at most {max_qty}")
    if not _is_multiple(quantity, step_size):
        raise ValueError(f"Quantity must be a multiple of step size {step_size}")

    return float(quantity)
