﻿import os
from decimal import Decimal
from pathlib import Path
from binance.client import Client
from dotenv import load_dotenv


def load_env_file(env_file: str = None):
    if env_file:
        env_path = Path(env_file)
        if not env_path.exists():
            raise FileNotFoundError(f"Env file not found: {env_file}")
        load_dotenv(dotenv_path=env_path)
    else:
        load_dotenv()

    api_key = os.getenv("BINANCE_API_KEY")
    api_secret = os.getenv("BINANCE_API_SECRET")
    return api_key, api_secret


def create_client(env_file: str = None):
    """Create Binance Futures Testnet client using credentials from .env."""
    api_key, api_secret = load_env_file(env_file)
    if not api_key or not api_secret:
        raise ValueError("BINANCE_API_KEY and BINANCE_API_SECRET must be set in the environment")
    return Client(api_key, api_secret, testnet=True)


def get_symbol_info(client, symbol: str):
    exchange_info = client.futures_exchange_info()
    for symbol_info in exchange_info.get("symbols", []):
        if symbol_info["symbol"] == symbol:
            return symbol_info
    raise ValueError(f"Symbol not found: {symbol}")


def get_current_price(client, symbol: str):
    ticker = client.futures_symbol_ticker(symbol=symbol)
    return Decimal(str(ticker["price"]))
