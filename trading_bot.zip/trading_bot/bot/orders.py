﻿import logging
import time
from decimal import Decimal


def place_order(client, symbol, side, order_type, quantity, price=None, stop_price=None):
    """Place MARKET, LIMIT, STOP_LIMIT, or STOP_MARKET order on Binance Futures Testnet."""
    if order_type == "LIMIT" and price is None:
        raise ValueError("Price required for LIMIT orders")
    if order_type == "STOP_LIMIT" and (price is None or stop_price is None):
        raise ValueError("Both price and stop price are required for STOP_LIMIT orders")
    if order_type == "STOP_MARKET" and stop_price is None:
        raise ValueError("Stop price is required for STOP_MARKET orders")

    if price is not None:
        order_price = Decimal(str(price)).normalize()
        price_str = format(order_price, "f")
    else:
        price_str = None

    stop_price_str = None
    if stop_price is not None:
        stop_price_str = format(Decimal(str(stop_price)).normalize(), "f")

    order_request = {
        "symbol": symbol,
        "side": side,
        "type": order_type,
        "quantity": quantity,
        "price": price_str,
        "stopPrice": stop_price_str,
        "timeInForce": "GTC" if order_type in ["LIMIT", "STOP_LIMIT"] else None,
    }
    logging.info(f"Order request: {order_request}")

    time.sleep(0.1)

    try:
        if order_type == "MARKET":
            order = client.futures_create_order(
                symbol=symbol,
                side=side,
                type="MARKET",
                quantity=quantity,
            )
        elif order_type == "LIMIT":
            order = client.futures_create_order(
                symbol=symbol,
                side=side,
                type="LIMIT",
                timeInForce="GTC",
                quantity=quantity,
                price=price_str,
            )
        elif order_type == "STOP_LIMIT":
            order = client.futures_create_order(
                symbol=symbol,
                side=side,
                type="STOP",
                timeInForce="GTC",
                quantity=quantity,
                price=price_str,
                stopPrice=stop_price_str,
            )
        else:  # STOP_MARKET
            order = client.futures_create_order(
                symbol=symbol,
                side=side,
                type="STOP_MARKET",
                stopPrice=stop_price_str,
                quantity=quantity,
            )

        logging.info(f"Order response: {order}")
        return order
    except Exception as error:
        logging.error(f"Error placing order: {error}")
        return {"error": str(error)}
